<?php
session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['usuario']['rol'] !== 'admin') {
  header("Location: ../auth/login.php");
  exit();
}
include '../backend/conexion.php';
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Gestión de Paquetes</title>
  <link rel="stylesheet" href="../css/styles.css">
</head>
<body>

  <!-- Menú lateral -->
  <div class="sidebar">
    <h2>Admin Viajeros</h2>
    <ul>
      <li><a href="dashboard.php">📊 Dashboard</a></li>
      <li><a href="paquetes.php" class="active">🧳 Paquetes</a></li>
      <li><a href="reservas.php">📋 Reservas</a></li>
      <li><a href="clientes.php">👥 Clientes</a></li>
      <li><a href="logout.php">🔓 Cerrar sesión</a></li>
    </ul>
  </div>

  <!-- Contenido principal -->
  <div class="main">
    <h1>Gestión de Paquetes</h1>

    <!-- Formulario -->
    <form action="../backend/crud_paquetes.php" method="POST" enctype="multipart/form-data" class="formulario">
      <input type="text" name="nombre" placeholder="Nombre del paquete" required />
      <textarea name="descripcion" placeholder="Descripción del paquete"></textarea>
      <input type="number" name="precio" placeholder="Precio" step="0.01" required />
      <input type="file" name="imagen" accept="image/*" required />
      <button type="submit" name="crear">Agregar paquete</button>
    </form>

    <!-- Tabla -->
    <table class="tabla">
      <tr>
        <th>Nombre</th>
        <th>Descripción</th>
        <th>Precio</th>
        <th>Imagen</th>
        <th>Acciones</th>
      </tr>
      <?php
        $res = $conn->query("SELECT * FROM paquetes");
        while ($row = $res->fetch_assoc()) {
          echo "<tr>
            <td>{$row['nombre']}</td>
            <td>{$row['descripcion']}</td>
            <td>$ {$row['precio']}</td>
            <td><img src='../{$row['imagen']}' width='80' /></td>
            <td>
              <a href='editar_paquete.php?id={$row['id']}'>Editar</a> |
              <form action='../backend/crud_paquetes.php' method='POST' style='display:inline;'>
                <input type='hidden' name='id' value='{$row['id']}' />
                <button name='eliminar'>Eliminar</button>
              </form>
            </td>
          </tr>";
        }
      ?>
    </table>
  </div>

</body>
</html>
