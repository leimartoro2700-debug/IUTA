<?php
session_start();
require_once('../conexion.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $nombre = $_POST['nombre'];
  $correo = $_POST['correo'];
  $contrasena = password_hash($_POST['contrasena'], PASSWORD_DEFAULT);
  $rol = 'cliente'; // 🔒 Forzado para evitar que se registren como administrador

  $stmt = $conn->prepare("INSERT INTO usuarios (nombre, correo, contrasena, rol) VALUES (?, ?, ?, ?)");
  $stmt->bind_param("ssss", $nombre, $correo, $contrasena, $rol);

  if ($stmt->execute()) {
    $_SESSION['usuario_id'] = $stmt->insert_id;
    header("Location: ../index.html"); // Redirige al inicio
    exit();
  } else {
    echo "❌ Error al registrar: " . $conn->error;
  }

  $stmt->close();
  $conn->close();
}
?>
