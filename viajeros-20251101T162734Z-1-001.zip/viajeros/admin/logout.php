<?php
session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['usuario']['rol'] !== 'admin') {
  header("Location: ../auth/login.php");
  exit();
}
?>

<?php
session_start();
session_destroy();
header("Location: ../auth/login.php");
?>
