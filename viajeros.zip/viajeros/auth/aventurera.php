<?php
header('Content-Type: application/json');
session_start();
include '../backend/conexion.php';
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Función para guardar interacción
function guardarInteraccion($conn, $pregunta, $respuesta, $usuario_id = null) {
  $stmt = $conn->prepare("INSERT INTO interacciones_asistente (usuario_id, pregunta, respuesta) VALUES (?, ?, ?)");
  $stmt->bind_param("iss", $usuario_id, $pregunta, $respuesta);
  $stmt->execute();
}

$accion = $_GET['accion'] ?? '';
$texto = $_GET['texto'] ?? '';
$usuario_id = $_SESSION['usuario_id'] ?? null;

switch ($accion) {
  case 'paquetes':
    $paquetes = $conn->query("SELECT nombre, descripcion, precio FROM paquetes");
    $datos = [];

    while ($p = $paquetes->fetch_assoc()) {
      $respuesta = "{$p['nombre']}: {$p['descripcion']} — $" . number_format($p['precio'], 2);
      guardarInteraccion($conn, $texto, $respuesta, $usuario_id);
      $datos[] = ['respuesta' => $respuesta];
    }

    echo json_encode($datos);
    break;

  case 'faq':
    $faq = [
      ["pregunta" => "¿Qué destinos ofrecen?", "respuesta" => "Tenemos paquetes a Los Roques, Roraima y Margarita."],
      ["pregunta" => "¿Qué incluye el paquete?", "respuesta" => "Incluye alojamiento, traslados, guía turístico y comidas."]
    ];

    foreach ($faq as $item) {
      guardarInteraccion($conn, $item['pregunta'], $item['respuesta'], $usuario_id);
    }

    echo json_encode($faq);
    break;

  default:
    $respuesta = "Lo siento, no entendí tu pregunta. Intenta con 'paquete' o 'faq'.";
    guardarInteraccion($conn, $texto, $respuesta, $usuario_id);
    echo json_encode(["error" => $respuesta]);
    break;
}
?>

