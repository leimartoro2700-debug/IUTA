<?php
session_start();
include 'conexion.php';

// 🔹 CREAR PAQUETE
if (isset($_POST['crear'])) {
  $nombre = $conn->real_escape_string($_POST['nombre']);
  $descripcion = $conn->real_escape_string($_POST['descripcion']);
  $precio = $_POST['precio'];

  $imagen_nombre = $_FILES['imagen']['name'];
  $imagen_temp = $_FILES['imagen']['tmp_name'];
  $carpeta_destino = '../imagenes/';

  if (!file_exists($carpeta_destino)) {
    mkdir($carpeta_destino, 0777, true);
  }

  $ruta_final = $carpeta_destino . basename($imagen_nombre);

  if (move_uploaded_file($imagen_temp, $ruta_final)) {
    $ruta_db = 'imagenes/' . basename($imagen_nombre);

    $sql = "INSERT INTO paquetes (nombre, descripcion, precio, imagen) 
            VALUES ('$nombre', '$descripcion', '$precio', '$ruta_db')";

    if ($conn->query($sql)) {
      header("Location: ../admin/paquetes.php");
      exit();
    } else {
      echo "❌ Error al guardar paquete: " . $conn->error;
    }
  } else {
    echo "❌ Error al subir la imagen.";
  }
}

// 🔹 ACTUALIZAR PAQUETE
if (isset($_POST['actualizar'])) {
  $id = $_POST['id'];
  $nombre = $conn->real_escape_string($_POST['nombre']);
  $descripcion = $conn->real_escape_string($_POST['descripcion']);
  $precio = $_POST['precio'];

  if (!empty($_FILES['imagen']['name'])) {
    $imagen_nombre = $_FILES['imagen']['name'];
    $imagen_temp = $_FILES['imagen']['tmp_name'];
    $carpeta_destino = '../imagenes/';
    $ruta_final = $carpeta_destino . basename($imagen_nombre);

    if (move_uploaded_file($imagen_temp, $ruta_final)) {
      $ruta_db = 'imagenes/' . basename($imagen_nombre);
      $conn->query("UPDATE paquetes SET nombre='$nombre', descripcion='$descripcion', precio='$precio', imagen='$ruta_db' WHERE id=$id");
    }
  } else {
    $conn->query("UPDATE paquetes SET nombre='$nombre', descripcion='$descripcion', precio='$precio' WHERE id=$id");
  }

  header("Location: ../admin/paquetes.php");
  exit();
}

// 🔹 ELIMINAR PAQUETE
if (isset($_POST['eliminar'])) {
  $id = $_POST['id'];

  $res = $conn->query("SELECT imagen FROM paquetes WHERE id = $id");
  if ($res->num_rows > 0) {
    $img = $res->fetch_assoc()['imagen'];
    $ruta = "../$img";
    if (file_exists($ruta)) {
      unlink($ruta);
    }
  }

  $conn->query("DELETE FROM paquetes WHERE id = $id");
  header("Location: ../admin/paquetes.php");
  exit();
}
?>
