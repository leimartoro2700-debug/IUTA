function enviarPregunta() {
  const input = document.getElementById("pregunta");
  const texto = input.value.trim();
  if (!texto) return;

  let accion = '';
  const lower = texto.toLowerCase();
  if (lower.includes("paquete") || lower.includes("tour") || lower.includes("precio")) {
    accion = 'paquetes';
  } else if (lower.includes("faq") || lower.includes("pregunta") || lower.includes("incluye")) {
    accion = 'faq';
  } else {
    accion = 'desconocido';
  }

  fetch(`auth/aventurera.php?accion=${accion}&texto=${encodeURIComponent(texto)}`)
    .then(res => res.json())
    .then(data => {
      const chat = document.getElementById("chat");
      if (Array.isArray(data)) {
        data.forEach(item => {
          const msg = document.createElement("p");
          msg.textContent = item.respuesta || item.pregunta;
          chat.appendChild(msg);
        });
      } else if (data.error) {
        const msg = document.createElement("p");
        msg.textContent = data.error;
        chat.appendChild(msg);
      }
    })
    .catch(err => console.error("Error:", err));
}
