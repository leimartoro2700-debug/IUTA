<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Registro de Cliente</title>
  <link rel="stylesheet" href="../css/registro.css" />
</head>
<body>

  <div class="registro-contenedor">
    <h2>Registro de Cliente</h2>
    <form action="procesar_registro.php" method="POST" class="formulario-registro">
      <input type="text" name="nombre" placeholder="Nombre completo" required />
      <input type="email" name="correo" placeholder="Correo electrónico" required />
      <input type="password" name="contrasena" placeholder="Contraseña" required />
      <input type="hidden" name="rol" value="cliente" />
      <button type="submit" class="boton-cta">Registrarse</button>
    </form>
    <p class="enlace-login">¿Ya tienes cuenta? <a href="login.php">Inicia sesión</a></p>
  </div>

</body>
</html>
