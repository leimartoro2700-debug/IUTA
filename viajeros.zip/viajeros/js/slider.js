// js/slider.js - Maneja el carrusel principal (destinos) y el carrusel de testimonios

document.addEventListener('DOMContentLoaded', () => {
    
    /**
     * Función genérica para inicializar cualquier carrusel con la clase 'active'.
     * @param {string} selector - Selector CSS para los elementos que rotarán (ej: '.hero-slider .slider-img').
     * @param {number} intervalTime - Tiempo en milisegundos para la rotación (ej: 6000 para 6 segundos).
     */
    function initializeCarousel(selector, intervalTime = 5000) {
        // Selecciona todos los elementos que forman parte del carrusel (imágenes o tarjetas)
        const items = document.querySelectorAll(selector);
        
        if (items.length <= 1) { 
            // Si hay 0 o 1 elemento, no hay nada que rotar, sale de la función.
            console.warn(`[Slider] No se encontró suficiente contenido para el carrusel: ${selector}`);
            return;
        }

        let currentIndex = 0;
        
        // 1. Inicializa: asegura que solo el primer elemento esté visible
        // Quita 'active' a todos
        items.forEach(item => item.classList.remove('active'));
        
        // Añade 'active' al primero
        items[0].classList.add('active'); 

        // Función principal para rotar los elementos
        function nextItem() {
            // A. Oculta el elemento actual
            items[currentIndex].classList.remove('active');
           
            // B. Calcula el índice del siguiente elemento (vuelve al inicio con el operador %)
            currentIndex = (currentIndex + 1) % items.length;
            
            // C. Muestra el nuevo elemento
            items[currentIndex].classList.add('active');
        }

        // 2. Inicia la rotación automática
        // El setInterval llama a nextItem cada 'intervalTime' milisegundos
        setInterval(nextItem, intervalTime); 
    }

    // A. Inicializar el Carrusel Principal (Destinos)
    // Rota cada 6 segundos
    initializeCarousel('.hero-slider .slider-img', 6000); 
    
    // B. Inicializar el Carrusel de Testimonios
    // Rota cada 8 segundos
    initializeCarousel('.testimonios-carrusel .testimonio-card', 8000); 
});