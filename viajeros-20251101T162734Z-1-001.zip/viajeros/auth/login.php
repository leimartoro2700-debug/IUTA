<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Iniciar sesión</title>
  <link rel="stylesheet" href="../css/login.css" />
</head>
<body>

  <div class="login-contenedor">
    <h2>Iniciar sesión</h2>
    <form action="validar.php" method="POST" class="formulario-login">
      <input type="email" name="correo" placeholder="Correo electrónico" required />
      <input type="password" name="contrasena" placeholder="Contraseña" required />
      <button type="submit" name="login" class="boton-cta">Iniciar sesión</button>
    </form>
    <p class="enlace-registro">¿No tienes cuenta? <a href="registro.php">Regístrate aquí</a></p>
  </div>

</body>
</html>
