<?php
session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['usuario']['rol'] !== 'admin') {
  header("Location: ../auth/login.php");
  exit();
}
include '../backend/conexion.php';
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Gestión de Reservas</title>
  <link rel="stylesheet" href="../css/styles.css">
</head>
<body>

  <!-- Menú lateral -->
  <div class="sidebar">
    <h2>Admin Viajeros</h2>
    <ul>
      <li><a href="dashboard.php">📊 Dashboard</a></li>
      <li><a href="paquetes.php">🧳 Paquetes</a></li>
      <li><a href="reservas.php" class="active">📋 Reservas</a></li>
      <li><a href="clientes.php">👥 Clientes</a></li>
      <li><a href="logout.php">🔓 Cerrar sesión</a></li>
    </ul>
  </div>

  <!-- Contenido principal -->
  <div class="main">
    <h1>Reservas realizadas</h1>

    <table class="tabla">
      <tr>
        <th>ID</th>
        <th>Cliente</th>
        <th>Paquete</th>
        <th>Cantidad</th>
        <th>Fecha</th>
      </tr>
      <?php
        $sql = "SELECT r.id AS id_reserva, u.nombre AS cliente, p.nombre AS paquete, r.cantidad, r.fecha_reserva
                FROM reservas r
                JOIN usuarios u ON r.id_usuario = u.id
                JOIN paquetes p ON r.id_paquete = p.id
                ORDER BY r.fecha_reserva DESC";

        $res = $conn->query($sql);

        if (!$res) {
          echo "<tr><td colspan='5' style='color:red;'>Error en la consulta: " . $conn->error . "</td></tr>";
        } else {
          while ($row = $res->fetch_assoc()) {
            echo "<tr>
              <td>{$row['id_reserva']}</td>
              <td>{$row['cliente']}</td>
              <td>{$row['paquete']}</td>
              <td>{$row['cantidad']}</td>
              <td>{$row['fecha_reserva']}</td>
            </tr>";
          }
        }
      ?>
    </table>
  </div>

</body>
</html>
