<?php
include 'conexion.php';

if (isset($_POST['eliminar'])) {
  $id = $_POST['id'];
  $conn->query("DELETE FROM usuarios WHERE id=$id");
  header("Location: ../admin/clientes.php");
}
?>
