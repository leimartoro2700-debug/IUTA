<?php
session_start();
include '../backend/conexion.php';

// Verificar si el usuario es administrador (opcional)
if ($_SESSION['rol'] !== 'admin') {
  header("Location: login.php");
  exit;
}

$consulta = $conn->query("
  SELECT ia.id, u.nombre AS usuario, ia.pregunta, ia.respuesta, ia.fecha
  FROM interacciones_asistente ia
  LEFT JOIN usuarios u ON ia.usuario_id = u.id
  ORDER BY ia.fecha DESC
");
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Interacciones del Asistente</title>
  <link rel="stylesheet" href="../css/styles.css">
</head>
<body>
  <h1>📊 Historial de Interacciones - Aventurera</h1>
  <table border="1" cellpadding="10" cellspacing="0">
    <thead>
      <tr>
        <th>ID</th>
        <th>Usuario</th>
        <th>Pregunta</th>
        <th>Respuesta</th>
        <th>Fecha</th>
      </tr>
    </thead>
    <tbody>
      <?php while ($fila = $consulta->fetch_assoc()): ?>
        <tr>
          <td><?= $fila['id'] ?></td>
          <td><?= $fila['usuario'] ?? 'Anónimo' ?></td>
          <td><?= htmlspecialchars($fila['pregunta']) ?></td>
          <td><?= htmlspecialchars($fila['respuesta']) ?></td>
          <td><?= $fila['fecha'] ?></td>
        </tr>
      <?php endwhile; ?>
    </tbody>
  </table>
</body>
</html>
