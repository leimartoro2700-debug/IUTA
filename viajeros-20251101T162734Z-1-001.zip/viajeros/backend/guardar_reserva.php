
<?php
session_start();
header('Content-Type: application/json');
include 'conexion.php';

if (!isset($_SESSION['usuario']) || $_SESSION['usuario']['rol'] !== 'cliente') {
  echo json_encode(["status" => "error", "mensaje" => "No autenticado"]);
  exit();
}

$id_usuario = $_SESSION['usuario']['id'];
$data = json_decode(file_get_contents("php://input"), true);

if (!is_array($data) || count($data) === 0) {
  echo json_encode(["status" => "error", "mensaje" => "Carrito vacío"]);
  exit();
}

$errores = 0;

foreach ($data as $item) {
  if (!isset($item['id']) || !isset($item['cantidad'])) {
    $errores++;
    continue;
  }

  $id_paquete = intval($item['id']);
  $cantidad = intval($item['cantidad']);
  $fecha = date("Y-m-d");

  $sql = "INSERT INTO reservas (id_usuario, id_paquete, cantidad, fecha_reserva) 
          VALUES (?, ?, ?, ?)";

  $stmt = $conn->prepare($sql);
  if ($stmt) {
    $stmt->bind_param("iiis", $id_usuario, $id_paquete, $cantidad, $fecha);
    if (!$stmt->execute()) {
      $errores++;
    }
    $stmt->close();
  } else {
    $errores++;
  }
}

echo json_encode($errores === 0
  ? ["status" => "ok"]
  : ["status" => "error", "mensaje" => "Error al guardar una o más reservas"]);
?>

