// 📦 Datos de los tours disponibles
const tours = [
  {
    id: 1,
    nombre: "Los Roques",
    precio: 150,
    imagen: "assets/img/roques.jpg",
    descripcion: "Explora el paraíso caribeño con aguas cristalinas y playas blancas.",
    duracion: "3 días / 2 noches",
    fechas: ["15/10/2025", "22/10/2025"]
  },
  {
    id: 2,
    nombre: "Roraima",
    precio: 150,
    imagen: "assets/img/roraima.jpg",
    descripcion: "Una aventura épica al tepuy más famoso de Venezuela.",
    duracion: "5 días / 4 noches",
    fechas: ["10/11/2025", "24/11/2025"]
  },
  {
    id: 3,
    nombre: "Isla de Margarita",
    precio: 150,
    imagen: "assets/img/margarita.png",
    descripcion: "Disfruta del sol, la playa y la cultura isleña.",
    duracion: "4 días / 3 noches",
    fechas: ["05/12/2025", "19/12/2025"]
  }
];

let carrito = [];

function obtenerTourPorId(id) {
  return tours.find(tour => tour.id === id);
}

function agregarAlCarrito(id) {
  const existente = carrito.find(item => item.id === id);
  if (existente) {
    existente.cantidad += 1;
  } else {
    const tour = obtenerTourPorId(id);
    carrito.push({ ...tour, cantidad: 1 });
  }
}

function restarCantidad(id) {
  const item = carrito.find(item => item.id === id);
  if (item) {
    item.cantidad -= 1;
    if (item.cantidad <= 0) {
      eliminarDelCarrito(id);
    }
  }
}

function eliminarDelCarrito(id) {
  carrito = carrito.filter(item => item.id !== id);
}

function obtenerTotales() {
  const totalProductos = carrito.length;
  const totalCompra = carrito.reduce((acc, item) => acc + item.precio * item.cantidad, 0);
  return { totalProductos, totalCompra };
}
