document.addEventListener("DOMContentLoaded", () => {
  renderizarTours();

  document.getElementById("carrito-icono").addEventListener("click", () => {
    document.getElementById("carrito-panel").classList.add("mostrar");
  });

  document.getElementById("cerrar-carrito").addEventListener("click", () => {
    document.getElementById("carrito-panel").classList.remove("mostrar");
  });

  document.getElementById("cerrar-modal").addEventListener("click", cerrarModal);

  document.getElementById("confirmar-reserva").addEventListener("click", () => {
    if (carrito.length === 0) {
      alert("Tu carrito está vacío.");
      return;
    }

    fetch("auth/verificar_sesion.php")
      .then(res => res.json())
      .then(data => {
        if (!data.logueado) {
          const confirmar = confirm("Debes iniciar sesión para confirmar tu reserva. ¿Deseas registrarte ahora?");
          if (confirmar) {
            window.location.href = "auth/registro.php";
          }
          return;
        }

        const carritoFiltrado = carrito.map(item => ({
          id: item.id,
          cantidad: item.cantidad
        }));

        fetch("backend/guardar_reserva.php", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(carritoFiltrado)
        })
        .then(res => res.json())
        .then(data => {
          if (data.status === "ok") {
            alert("✅ Reserva guardada correctamente.");
            carrito = [];
            actualizarCarrito();
            actualizarContador();
            document.getElementById("carrito-panel").classList.remove("mostrar");
          } else {
            alert("❌ Error: " + data.mensaje);
          }
        })
        .catch(error => {
          console.error("Error al enviar reserva:", error);
          alert("⚠️ Problema de conexión.");
        });
      });
  });
});

function modificarCantidad(id, accion) {
  if (accion === "sumar") {
    agregarAlCarrito(id);
  } else if (accion === "restar") {
    restarCantidad(id);
  } else if (accion === "eliminar") {
    eliminarDelCarrito(id);
  }

  actualizarCarrito();
  actualizarContador();
}
