<?php
session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['usuario']['rol'] !== 'admin') {
  header("Location: ../auth/login.php");
  exit();
}
include '../backend/conexion.php';

if (isset($_GET['id'])) {
  $id = intval($_GET['id']);
  $resultado = $conn->query("SELECT * FROM paquetes WHERE id = $id");
  if ($resultado->num_rows > 0) {
    $paquete = $resultado->fetch_assoc();
  } else {
    echo "<p style='color:red;'>Paquete no encontrado.</p>";
    exit();
  }
} else {
  echo "<p style='color:red;'>ID no especificado.</p>";
  exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Editar Paquete</title>
  <link rel="stylesheet" href="../css/styles.css">
  <style>
    .editar-paquete {
      max-width: 600px;
      margin: 40px auto;
      background: #fff;
      padding: 30px;
      border-radius: 12px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.1);
      font-family: 'Segoe UI', sans-serif;
    }

    .editar-paquete h1 {
      text-align: center;
      color: #007bff;
      margin-bottom: 25px;
    }

    .editar-paquete label {
      display: block;
      margin-bottom: 6px;
      font-weight: bold;
      color: #333;
    }

    .editar-paquete input[type="text"],
    .editar-paquete input[type="number"],
    .editar-paquete textarea,
    .editar-paquete input[type="file"] {
      width: 100%;
      padding: 10px;
      margin-bottom: 15px;
      border: 1px solid #ccc;
      border-radius: 6px;
      font-size: 15px;
    }

    .editar-paquete img {
      display: block;
      margin: 10px auto;
      border-radius: 8px;
      max-width: 100%;
      height: auto;
    }

    .editar-paquete button {
      background-color: #007bff;
      color: white;
      border: none;
      padding: 12px;
      border-radius: 6px;
      font-size: 16px;
      cursor: pointer;
      width: 100%;
      transition: background-color 0.3s;
    }

    .editar-paquete button:hover {
      background-color: #0056b3;
    }
  </style>
</head>
<body>
  <div class="editar-paquete">
    <h1>Editar Paquete</h1>
    <form action="../backend/crud_paquetes.php" method="POST" enctype="multipart/form-data">
      <input type="hidden" name="id" value="<?php echo $paquete['id']; ?>" />

      <label for="nombre">Nombre del paquete</label>
      <input type="text" name="nombre" id="nombre" value="<?php echo htmlspecialchars($paquete['nombre']); ?>" required />

      <label for="descripcion">Descripción</label>
      <textarea name="descripcion" id="descripcion" rows="4"><?php echo htmlspecialchars($paquete['descripcion']); ?></textarea>

      <label for="precio">Precio</label>
      <input type="number" name="precio" id="precio" value="<?php echo $paquete['precio']; ?>" step="0.01" required />

      <label>Imagen actual</label>
      <img src="../<?php echo $paquete['imagen']; ?>" alt="Imagen actual" />

      <label for="imagen">Nueva imagen (opcional)</label>
      <input type="file" name="imagen" id="imagen" accept="image/*" />

      <button type="submit" name="actualizar">Guardar cambios</button>
    </form>
  </div>
</body>
</html>
