<?php
session_start();

if (!isset($_SESSION['usuario']) || $_SESSION['usuario']['rol'] !== 'admin') {
  header("Location: ../auth/login.php");
  exit();
}
include '../backend/conexion.php';
?>

<?php
if (!isset($_SESSION['usuario']) || $_SESSION['usuario']['rol'] !== 'admin') {
  header("Location: ../auth/login.php");
  exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Panel de Administración</title>
  <link rel="stylesheet" href="../css/styles.css">
</head>
<body>
  <div class="sidebar">
    <h2>Admin Viajeros</h2>
   
  </div>

  <div class="main">
    <h1>Bienvenido, <?php echo $_SESSION['usuario']['nombre']; ?></h1>
    <div class="cards">
      <div class="card">
        <h3>Total Paquetes</h3>
        <p>
          <?php
            include '../backend/conexion.php';
            echo $conn->query("SELECT COUNT(*) AS total FROM paquetes")->fetch_assoc()['total'];
          ?>
        </p>
      </div>
      <div class="card">
        <h3>Total Reservas</h3>
        <p>
          <?php
            echo $conn->query("SELECT COUNT(*) AS total FROM reservas")->fetch_assoc()['total'];
          ?>
        </p>
      </div>
      <div class="card">
        <h3>Total Clientes</h3>
        <p>
          <?php
            echo $conn->query("SELECT COUNT(*) AS total FROM usuarios WHERE rol='cliente'")->fetch_assoc()['total'];
          ?>
        </p>
      </div>
    </div>
  </div>
</body>
</html>

<div class="sidebar">
  <h2>Admin Viajeros</h2>
  <ul>
    <li><a href="dashboard.php">📊 Dashboard</a></li>
    <li><a href="paquetes.php">🧳 Paquetes</a></li>
    <li><a href="reservas.php">📋 Reservas</a></li>
    <li><a href="clientes.php">👥 Clientes</a></li>
    <li><a href="logout.php">🔓 Cerrar sesión</a></li>
  </ul>
</div>
