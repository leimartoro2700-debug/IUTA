<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();
include '../backend/conexion.php';

// 🔹 PROCESAR REGISTRO
if (isset($_POST['registro'])) {
  $nombre = $conn->real_escape_string($_POST['nombre']);
  $correo = $conn->real_escape_string($_POST['correo']);
  $clave = password_hash($_POST['contrasena'], PASSWORD_DEFAULT);
  $rol = 'cliente'; // 🔒 Forzado para evitar que se registren como admin

  // Verificar si el correo ya existe
  $verificar = $conn->query("SELECT id FROM usuarios WHERE correo = '$correo'");
  if ($verificar->num_rows > 0) {
    echo "<p style='color:red;'>Este correo ya está registrado.</p>";
    exit();
  }

  // Insertar nuevo usuario
  $sql = "INSERT INTO usuarios (nombre, correo, contrasena, rol) VALUES ('$nombre', '$correo', '$clave', '$rol')";
  if ($conn->query($sql)) {
    header("Location: login.php"); // Redirige al login
    exit();
  } else {
    echo "<p style='color:red;'>Error al registrar: " . $conn->error . "</p>";
    exit();
  }
}

// 🔹 PROCESAR LOGIN
if (isset($_POST['login'])) {
  $correo = $_POST['correo'];
  $contrasena = $_POST['contrasena'];

  $sql = "SELECT * FROM usuarios WHERE correo = '$correo'";
  $resultado = $conn->query($sql);

  if ($resultado->num_rows > 0) {
    $usuario = $resultado->fetch_assoc();

    if (password_verify($contrasena, $usuario['contrasena'])) {
      $_SESSION['usuario'] = [
        'id' => $usuario['id'],
        'nombre' => $usuario['nombre'],
        'rol' => $usuario['rol']
      ];

      if ($usuario['rol'] === 'admin') {
        header("Location: ../admin/dashboard.php");
      } else {
        header("Location: ../index.html"); // ✅ Redirige al HTML principal
      }
      exit();
    } else {
      echo "<p style='color:red;'>⚠️ Contraseña incorrecta.</p>";
    }
  } else {
    echo "<p style='color:red;'>⚠️ Usuario no encontrado.</p>";
  }
}
?>
