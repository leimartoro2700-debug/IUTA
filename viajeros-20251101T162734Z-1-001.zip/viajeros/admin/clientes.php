<?php
session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['usuario']['rol'] !== 'admin') {
  header("Location: ../auth/login.php");
  exit();
}
include '../backend/conexion.php';
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Gestión de Clientes</title>
  <link rel="stylesheet" href="../css/styles.css">
</head>
<body>

  <!-- Menú lateral -->
  <div class="sidebar">
    <h2>Admin Viajeros</h2>
    <ul>
      <li><a href="dashboard.php">📊 Dashboard</a></li>
      <li><a href="paquetes.php">🧳 Paquetes</a></li>
      <li><a href="reservas.php">📋 Reservas</a></li>
      <li><a href="clientes.php" class="active">👥 Clientes</a></li>
      <li><a href="logout.php">🔓 Cerrar sesión</a></li>
    </ul>
  </div>

  <!-- Contenido principal -->
  <div class="main">
    <h1>Clientes registrados</h1>

    <table class="tabla">
      <tr>
        <th>Nombre</th>
        <th>Correo</th>
        <th>Acciones</th>
      </tr>
      <?php
        $res = $conn->query("SELECT * FROM usuarios WHERE rol='cliente'");
        while ($row = $res->fetch_assoc()) {
          echo "<tr>
            <td>{$row['nombre']}</td>
            <td>{$row['correo']}</td>
            <td>
              <form action='../backend/crud_clientes.php' method='POST'>
                <input type='hidden' name='id' value='{$row['id']}' />
                <button name='eliminar'>Eliminar</button>
              </form>
            </td>
          </tr>";
        }
      ?>
    </table>
  </div>

</body>
</html>
