function renderizarTours() {
  const contenedor = document.querySelector("#tours");
  contenedor.innerHTML = "";

  tours.forEach(tour => {
    const tarjeta = document.createElement("div");
    tarjeta.classList.add("tarjeta-tour");

    tarjeta.innerHTML = `
      <img src="${tour.imagen}" alt="${tour.nombre}" />
      <div class="contenido">
        <h3>${tour.nombre}</h3>
        <p>Precio: $${tour.precio}</p>
        <button class="boton-cta" onclick="mostrarDetalles(${tour.id})">Ver detalles</button>
        <button class="boton-cta" onclick="agregarAlCarrito(${tour.id}); actualizarCarrito(); actualizarContador();">Reservar ahora</button>
      </div>
    `;

    contenedor.appendChild(tarjeta);
  });
}

function mostrarDetalles(id) {
  const tour = obtenerTourPorId(id);
  const modal = document.querySelector("#modal-detalles");
  const contenido = document.querySelector("#contenido-modal");

  contenido.innerHTML = `
    <h2>${tour.nombre}</h2>
    <p>${tour.descripcion}</p>
    <p><strong>Duración:</strong> ${tour.duracion}</p>
    <p><strong>Fechas disponibles:</strong> ${tour.fechas.join(", ")}</p>
  `;

  modal.classList.add("activo");
}

function cerrarModal() {
  document.querySelector("#modal-detalles").classList.remove("activo");
}

function actualizarCarrito() {
  const panel = document.querySelector("#items-carrito");
  panel.innerHTML = "";

  carrito.forEach(item => {
    const div = document.createElement("div");
    div.classList.add("item");

    div.innerHTML = `
      <p><strong>${item.nombre}</strong> - $${item.precio} x ${item.cantidad}</p>
      <button onclick="modificarCantidad(${item.id}, 'sumar')">+</button>
      <button onclick="modificarCantidad(${item.id}, 'restar')">-</button>
      <button onclick="modificarCantidad(${item.id}, 'eliminar')">🗑️</button>
    `;

    panel.appendChild(div);
  });

  const { totalProductos, totalCompra } = obtenerTotales();
  document.querySelector("#total-productos").textContent = totalProductos;
  document.querySelector("#total-compra").textContent = totalCompra.toFixed(2);
}

function actualizarContador() {
  document.querySelector("#contador-carrito").textContent = carrito.length;
}
